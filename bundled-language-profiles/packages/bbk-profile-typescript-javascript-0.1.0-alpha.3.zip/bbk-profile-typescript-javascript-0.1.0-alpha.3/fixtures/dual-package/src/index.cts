export const mode = "cjs";
